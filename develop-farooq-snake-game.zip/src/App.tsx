import { useEffect, useRef, useState, useCallback } from 'react';
import { useSnakeGame } from './hooks/useSnakeGame';
import GameCanvas from './components/GameCanvas';
import GameOverlay from './components/GameOverlay';
import GameHUD from './components/GameHUD';
import TouchControls from './components/TouchControls';
import { sounds } from './utils/sounds';

const GRID_SIZE = 20;

function useWindowSize() {
  const [size, setSize] = useState({ width: window.innerWidth, height: window.innerHeight });
  useEffect(() => {
    const handler = () => setSize({ width: window.innerWidth, height: window.innerHeight });
    window.addEventListener('resize', handler);
    return () => window.removeEventListener('resize', handler);
  }, []);
  return size;
}

function getGameDimensions(windowWidth: number, windowHeight: number) {
  const isMobile = windowWidth < 640;
  const hudHeight = 90;
  const controlsHeight = isMobile ? 200 : 0;
  const headerHeight = 80;
  const padding = isMobile ? 16 : 32;

  const availableWidth = windowWidth - padding * 2;
  const availableHeight = windowHeight - headerHeight - hudHeight - controlsHeight - padding * 2;

  const maxSize = isMobile ? Math.min(availableWidth, availableHeight, 360) : Math.min(availableWidth, availableHeight, 520);
  const canvasSize = Math.floor(maxSize / GRID_SIZE) * GRID_SIZE;
  const cellSize = canvasSize / GRID_SIZE;

  return { canvasSize, cellSize, isMobile };
}

export default function App() {
  const { state, startGame, pauseGame, resumeGame, changeDirection } = useSnakeGame();
  const { width, height } = useWindowSize();
  const { canvasSize, cellSize, isMobile } = getGameDimensions(width, height);

  const prevStatusRef = useRef(state.status);
  const prevLevelRef = useRef(state.level);
  const prevFoodRef = useRef(state.food);
  const [isPulsing, setIsPulsing] = useState(false);

  // Sound effects triggered by state changes
  useEffect(() => {
    const prev = prevStatusRef.current;
    const curr = state.status;
    prevStatusRef.current = curr;

    if (prev === 'IDLE' && curr === 'PLAYING') sounds.start();
    else if (prev === 'PLAYING' && curr === 'PAUSED') sounds.pause();
    else if (prev === 'PAUSED' && curr === 'PLAYING') sounds.resume();
    else if (curr === 'GAME_OVER') sounds.gameOver();
    else if (prev === 'GAME_OVER' && curr === 'PLAYING') sounds.start();
  }, [state.status]);

  useEffect(() => {
    if (state.food !== prevFoodRef.current && state.status === 'PLAYING') {
      prevFoodRef.current = state.food;
      // Food was eaten
      if (state.food.type === 'BONUS') sounds.eatBonus();
      else if (state.food.type === 'SHRINK') sounds.eatShrink();
      else sounds.eat();

      if (state.combo >= 3) sounds.combo(state.combo);

      // Pulse effect
      setIsPulsing(true);
      setTimeout(() => setIsPulsing(false), 300);
    }
  }, [state.food, state.status, state.combo]);

  useEffect(() => {
    if (state.level !== prevLevelRef.current && state.level > 1) {
      prevLevelRef.current = state.level;
      sounds.levelUp();
    }
  }, [state.level]);

  const handlePauseResume = useCallback(() => {
    if (state.status === 'PLAYING') pauseGame();
    else if (state.status === 'PAUSED') resumeGame();
  }, [state.status, pauseGame, resumeGame]);

  // Prevent scroll on mobile
  useEffect(() => {
    const prevent = (e: TouchEvent) => {
      if ((e.target as HTMLElement)?.closest?.('.game-area')) {
        e.preventDefault();
      }
    };
    document.addEventListener('touchmove', prevent, { passive: false });
    return () => document.removeEventListener('touchmove', prevent);
  }, []);

  const isNewRecord = state.status === 'GAME_OVER' && state.score > 0 && state.score >= state.highScore;

  return (
    <div
      className="min-h-screen flex flex-col items-center select-none overflow-hidden"
      style={{
        background: 'linear-gradient(135deg, #0f0c29, #1a1a2e, #16213e)',
        fontFamily: '"Inter", -apple-system, BlinkMacSystemFont, sans-serif',
      }}
    >
      {/* Animated background stars */}
      <BackgroundStars />

      {/* Header */}
      <header className="w-full flex items-center justify-between px-4 sm:px-6 py-3 flex-shrink-0" style={{ maxWidth: 600 }}>
        <div className="flex items-center gap-2">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center text-lg"
            style={{
              background: 'linear-gradient(135deg, #22c55e, #16a34a)',
              boxShadow: '0 0 16px rgba(34,197,94,0.4)',
            }}
          >
            🐍
          </div>
          <div>
            <h1
              className="text-xl font-black tracking-tight leading-none"
              style={{
                background: 'linear-gradient(135deg, #4ade80, #22d3ee, #a78bfa)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              Farooq Snake
            </h1>
            <p className="text-slate-500 text-[10px] leading-none mt-0.5">Classic Reborn</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Status badge */}
          <div
            className="px-3 py-1.5 rounded-xl text-xs font-bold transition-all duration-300"
            style={{
              background:
                state.status === 'PLAYING' ? 'rgba(34,197,94,0.15)'
                  : state.status === 'PAUSED' ? 'rgba(59,130,246,0.15)'
                    : state.status === 'GAME_OVER' ? 'rgba(239,68,68,0.15)'
                      : 'rgba(255,255,255,0.07)',
              border:
                state.status === 'PLAYING' ? '1px solid rgba(34,197,94,0.35)'
                  : state.status === 'PAUSED' ? '1px solid rgba(59,130,246,0.35)'
                    : state.status === 'GAME_OVER' ? '1px solid rgba(239,68,68,0.35)'
                      : '1px solid rgba(255,255,255,0.1)',
              color:
                state.status === 'PLAYING' ? '#4ade80'
                  : state.status === 'PAUSED' ? '#60a5fa'
                    : state.status === 'GAME_OVER' ? '#f87171'
                      : '#64748b',
            }}
          >
            {state.status === 'PLAYING' ? '● LIVE'
              : state.status === 'PAUSED' ? '⏸ PAUSED'
                : state.status === 'GAME_OVER' ? '💀 OVER'
                  : '○ IDLE'}
          </div>

          {/* Pause/Resume button */}
          {(state.status === 'PLAYING' || state.status === 'PAUSED') && !isMobile && (
            <button
              onClick={handlePauseResume}
              className="w-9 h-9 rounded-xl flex items-center justify-center text-sm font-bold transition-all duration-150 active:scale-90 hover:opacity-80"
              style={{
                background: 'rgba(255,255,255,0.07)',
                border: '1px solid rgba(255,255,255,0.12)',
                color: '#94a3b8',
              }}
            >
              {state.status === 'PLAYING' ? '⏸' : '▶'}
            </button>
          )}
        </div>
      </header>

      {/* Main game area */}
      <main className="flex flex-col items-center flex-1 w-full game-area px-4" style={{ maxWidth: 600 }}>
        {/* HUD */}
        <div className="w-full mb-3" style={{ maxWidth: canvasSize }}>
          <GameHUD
            score={state.score}
            highScore={state.highScore}
            level={state.level}
            combo={state.combo}
            snakeLength={state.snake.length}
          />
        </div>

        {/* Canvas container */}
        <div
          className="relative flex-shrink-0 transition-all duration-300"
          style={{
            width: canvasSize,
            height: canvasSize,
            boxShadow: isPulsing
              ? '0 0 60px rgba(74,222,128,0.6), 0 0 120px rgba(74,222,128,0.3)'
              : isNewRecord
                ? '0 0 60px rgba(251,191,36,0.5), 0 0 100px rgba(251,191,36,0.2)'
                : '0 0 40px rgba(74,222,128,0.15), 0 20px 60px rgba(0,0,0,0.5)',
            borderRadius: 16,
          }}
        >
          <GameCanvas
            snake={state.snake}
            food={state.food}
            particles={state.particles}
            gridSize={GRID_SIZE}
            cellSize={cellSize}
            canvasSize={canvasSize}
            isPulsing={isPulsing}
          />
          <GameOverlay
            status={state.status}
            score={state.score}
            highScore={state.highScore}
            level={state.level}
            onStart={startGame}
            onResume={resumeGame}
            onRestart={startGame}
          />
        </div>

        {/* Mobile touch controls */}
        {isMobile && (
          <TouchControls
            onDirection={changeDirection}
            onPause={handlePauseResume}
            isPlaying={state.status === 'PLAYING'}
          />
        )}

        {/* Desktop keyboard hint */}
        {!isMobile && state.status === 'PLAYING' && (
          <div className="mt-3 flex gap-3 items-center flex-wrap justify-center">
            {[
              { keys: ['W', '▲'], label: 'Up' },
              { keys: ['S', '▼'], label: 'Down' },
              { keys: ['A', '◀'], label: 'Left' },
              { keys: ['D', '▶'], label: 'Right' },
              { keys: ['Space'], label: 'Pause' },
            ].map(item => (
              <div key={item.label} className="flex items-center gap-1">
                {item.keys.map(k => (
                  <kbd
                    key={k}
                    className="px-2 py-1 rounded-lg text-xs font-mono text-slate-400 font-bold"
                    style={{
                      background: 'rgba(255,255,255,0.06)',
                      border: '1px solid rgba(255,255,255,0.12)',
                      boxShadow: '0 2px 0 rgba(0,0,0,0.3)',
                    }}
                  >
                    {k}
                  </kbd>
                ))}
                <span className="text-slate-600 text-xs">{item.label}</span>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="py-2 pb-3 text-center">
        <p className="text-slate-700 text-xs">
          Made with ❤️ by <span className="text-slate-500 font-semibold">Farooq</span>
        </p>
      </footer>
    </div>
  );
}

// Animated background stars
function BackgroundStars() {
  const stars = useRef(
    Array.from({ length: 60 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: 0.5 + Math.random() * 2,
      opacity: 0.1 + Math.random() * 0.4,
      duration: 2 + Math.random() * 4,
      delay: Math.random() * 4,
    }))
  ).current;

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden" style={{ zIndex: 0 }}>
      {stars.map(star => (
        <div
          key={star.id}
          className="absolute rounded-full bg-white"
          style={{
            left: `${star.x}%`,
            top: `${star.y}%`,
            width: star.size,
            height: star.size,
            opacity: star.opacity,
            animation: `twinkle ${star.duration}s ease-in-out ${star.delay}s infinite alternate`,
          }}
        />
      ))}
      <style>{`
        @keyframes twinkle {
          0% { opacity: 0.05; transform: scale(0.8); }
          100% { opacity: 0.5; transform: scale(1.2); }
        }
        @keyframes animate-shake {
          0%, 100% { transform: translateX(0); }
          20% { transform: translateX(-8px) rotate(-1deg); }
          40% { transform: translateX(8px) rotate(1deg); }
          60% { transform: translateX(-6px); }
          80% { transform: translateX(6px); }
        }
        .animate-shake {
          animation: animate-shake 0.5s ease-in-out;
        }
      `}</style>
    </div>
  );
}
