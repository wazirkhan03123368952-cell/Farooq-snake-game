// Web Audio API sound effects for Farooq Snake

let audioCtx: AudioContext | null = null;

function getAudioCtx(): AudioContext {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  return audioCtx;
}

function playTone(
  frequency: number,
  duration: number,
  type: OscillatorType = 'square',
  gainVal = 0.15,
  fadeOut = true
) {
  try {
    const ctx = getAudioCtx();
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);

    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, ctx.currentTime);

    gainNode.gain.setValueAtTime(gainVal, ctx.currentTime);
    if (fadeOut) {
      gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    }

    oscillator.start(ctx.currentTime);
    oscillator.stop(ctx.currentTime + duration);
  } catch (e) {
    // Silently fail if audio is not available
  }
}

export const sounds = {
  eat: () => {
    playTone(523, 0.08, 'sine', 0.2);
    setTimeout(() => playTone(659, 0.08, 'sine', 0.2), 60);
    setTimeout(() => playTone(784, 0.1, 'sine', 0.2), 120);
  },

  eatBonus: () => {
    playTone(523, 0.06, 'sine', 0.25);
    setTimeout(() => playTone(659, 0.06, 'sine', 0.25), 50);
    setTimeout(() => playTone(784, 0.06, 'sine', 0.25), 100);
    setTimeout(() => playTone(1046, 0.15, 'sine', 0.25), 150);
  },

  eatShrink: () => {
    playTone(880, 0.1, 'sine', 0.2);
    setTimeout(() => playTone(1108, 0.2, 'triangle', 0.2), 80);
  },

  levelUp: () => {
    const notes = [523, 659, 784, 1046, 1318];
    notes.forEach((note, i) => {
      setTimeout(() => playTone(note, 0.15, 'sine', 0.2), i * 80);
    });
  },

  gameOver: () => {
    playTone(330, 0.3, 'square', 0.2);
    setTimeout(() => playTone(277, 0.3, 'square', 0.2), 200);
    setTimeout(() => playTone(220, 0.5, 'square', 0.2), 400);
  },

  start: () => {
    const notes = [262, 330, 392, 523];
    notes.forEach((note, i) => {
      setTimeout(() => playTone(note, 0.12, 'sine', 0.18), i * 100);
    });
  },

  move: () => {
    playTone(200, 0.03, 'square', 0.04, true);
  },

  pause: () => {
    playTone(440, 0.1, 'sine', 0.15);
    setTimeout(() => playTone(330, 0.15, 'sine', 0.15), 100);
  },

  resume: () => {
    playTone(330, 0.1, 'sine', 0.15);
    setTimeout(() => playTone(440, 0.15, 'sine', 0.15), 100);
  },

  combo: (count: number) => {
    const freq = 400 + count * 50;
    playTone(freq, 0.12, 'sine', 0.18);
  },
};
