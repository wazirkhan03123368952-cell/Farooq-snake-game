import { useEffect, useState } from 'react';
import type { GameStatus } from '../hooks/useSnakeGame';

interface GameOverlayProps {
  status: GameStatus;
  score: number;
  highScore: number;
  level: number;
  onStart: () => void;
  onResume: () => void;
  onRestart: () => void;
}

function AnimatedNumber({ value }: { value: number }) {
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    const duration = 800;
    const startTime = performance.now();

    function update(now: number) {
      const elapsed = now - startTime;
      const t = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - t, 3);
      setDisplay(Math.round(eased * value));
      if (t < 1) requestAnimationFrame(update);
    }

    requestAnimationFrame(update);
  }, [value]);

  return <>{display}</>;
}

export default function GameOverlay({
  status,
  score,
  highScore,
  level,
  onStart,
  onResume,
  onRestart,
}: GameOverlayProps) {
  const [visible, setVisible] = useState(false);
  const [shake, setShake] = useState(false);

  useEffect(() => {
    if (status !== 'PLAYING') {
      const t = setTimeout(() => setVisible(true), 50);
      return () => clearTimeout(t);
    } else {
      setVisible(false);
    }
  }, [status]);

  useEffect(() => {
    if (status === 'GAME_OVER') {
      setShake(true);
      const t = setTimeout(() => setShake(false), 600);
      return () => clearTimeout(t);
    }
  }, [status]);

  if (status === 'PLAYING') return null;

  return (
    <div
      className={`absolute inset-0 flex items-center justify-center rounded-2xl transition-all duration-300
        ${visible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}
        ${shake ? 'animate-shake' : ''}
      `}
      style={{
        background:
          status === 'GAME_OVER'
            ? 'rgba(15, 23, 42, 0.92)'
            : 'rgba(15, 23, 42, 0.88)',
        backdropFilter: 'blur(12px)',
      }}
    >
      {status === 'IDLE' && <IdleScreen onStart={onStart} />}
      {status === 'PAUSED' && <PausedScreen onResume={onResume} onRestart={onRestart} score={score} level={level} />}
      {status === 'GAME_OVER' && (
        <GameOverScreen
          score={score}
          highScore={highScore}
          level={level}
          onRestart={onRestart}
        />
      )}
    </div>
  );
}

function IdleScreen({ onStart }: { onStart: () => void }) {
  const [frame, setFrame] = useState(0);
  const emojis = ['🐍', '🍎', '⭐', '💎', '⚡'];

  useEffect(() => {
    const t = setInterval(() => setFrame(f => (f + 1) % emojis.length), 600);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="text-center px-6 py-8 w-full max-w-sm mx-auto">
      {/* Animated snake emoji */}
      <div className="text-7xl mb-4 animate-bounce" style={{ animationDuration: '1.5s' }}>
        {emojis[frame]}
      </div>

      {/* Title */}
      <h1
        className="text-4xl font-black mb-2 tracking-tight"
        style={{
          background: 'linear-gradient(135deg, #4ade80, #22d3ee, #a78bfa)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          filter: 'drop-shadow(0 0 20px rgba(74,222,128,0.4))',
        }}
      >
        Farooq Snake
      </h1>
      <p className="text-slate-400 text-sm mb-8">The Ultimate Snake Experience</p>

      {/* Legend */}
      <div className="grid grid-cols-2 gap-2 mb-8 text-xs">
        {[
          { emoji: '🍎', label: 'Apple', pts: '+10', color: '#ef4444' },
          { emoji: '⭐', label: 'Star', pts: '+30', color: '#f59e0b' },
          { emoji: '⚡', label: 'Bolt', pts: '+20', color: '#8b5cf6' },
          { emoji: '💎', label: 'Diamond', pts: '+50', color: '#06b6d4' },
        ].map(item => (
          <div
            key={item.label}
            className="flex items-center gap-2 rounded-xl px-3 py-2"
            style={{ background: item.color + '22', border: `1px solid ${item.color}44` }}
          >
            <span className="text-lg">{item.emoji}</span>
            <div className="text-left">
              <div className="text-white font-semibold">{item.label}</div>
              <div style={{ color: item.color }}>{item.pts} pts</div>
            </div>
          </div>
        ))}
      </div>

      {/* Controls hint */}
      <div className="flex gap-3 justify-center mb-8 flex-wrap">
        {['↑ W', '↓ S', '← A', '→ D'].map(key => (
          <span
            key={key}
            className="px-2 py-1 rounded-lg text-xs font-mono text-slate-300 font-bold"
            style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)' }}
          >
            {key}
          </span>
        ))}
      </div>

      <button
        onClick={onStart}
        className="w-full py-4 rounded-2xl font-black text-xl text-white transition-all duration-200 active:scale-95 hover:scale-105"
        style={{
          background: 'linear-gradient(135deg, #22c55e, #16a34a)',
          boxShadow: '0 0 30px rgba(34,197,94,0.5), 0 4px 15px rgba(0,0,0,0.3)',
        }}
      >
        🎮 Start Game
      </button>
      <p className="text-slate-500 text-xs mt-3">Press <kbd className="text-slate-300">Space</kbd> or <kbd className="text-slate-300">Enter</kbd> to start</p>
    </div>
  );
}

function PausedScreen({
  onResume,
  onRestart,
  score,
  level,
}: {
  onResume: () => void;
  onRestart: () => void;
  score: number;
  level: number;
}) {
  return (
    <div className="text-center px-6 py-8 w-full max-w-sm mx-auto">
      <div className="text-6xl mb-4">⏸️</div>
      <h2
        className="text-4xl font-black mb-1"
        style={{
          background: 'linear-gradient(135deg, #60a5fa, #a78bfa)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
        }}
      >
        Paused
      </h2>
      <p className="text-slate-400 text-sm mb-8">Take a breather!</p>

      <div className="grid grid-cols-2 gap-3 mb-8">
        <StatCard label="Score" value={score} color="#60a5fa" />
        <StatCard label="Level" value={level} color="#a78bfa" />
      </div>

      <div className="flex flex-col gap-3">
        <button
          onClick={onResume}
          className="w-full py-4 rounded-2xl font-black text-xl text-white transition-all duration-200 active:scale-95 hover:scale-105"
          style={{
            background: 'linear-gradient(135deg, #3b82f6, #6366f1)',
            boxShadow: '0 0 30px rgba(59,130,246,0.4), 0 4px 15px rgba(0,0,0,0.3)',
          }}
        >
          ▶️ Resume
        </button>
        <button
          onClick={onRestart}
          className="w-full py-3 rounded-2xl font-bold text-lg transition-all duration-200 active:scale-95 hover:opacity-80"
          style={{
            background: 'rgba(255,255,255,0.08)',
            border: '1px solid rgba(255,255,255,0.15)',
            color: '#94a3b8',
          }}
        >
          🔄 Restart
        </button>
      </div>
      <p className="text-slate-500 text-xs mt-3">Press <kbd className="text-slate-300">Esc</kbd> or <kbd className="text-slate-300">Space</kbd> to resume</p>
    </div>
  );
}

function GameOverScreen({
  score,
  highScore,
  level,
  onRestart,
}: {
  score: number;
  highScore: number;
  level: number;
  onRestart: () => void;
}) {
  const isNewRecord = score >= highScore && score > 0;

  return (
    <div className="text-center px-6 py-8 w-full max-w-sm mx-auto">
      <div className="text-6xl mb-3 animate-bounce" style={{ animationDuration: '1s' }}>
        {isNewRecord ? '🏆' : '💀'}
      </div>

      <h2
        className="text-4xl font-black mb-1"
        style={{
          background: isNewRecord
            ? 'linear-gradient(135deg, #fbbf24, #f59e0b, #d97706)'
            : 'linear-gradient(135deg, #f87171, #ef4444)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          filter: isNewRecord ? 'drop-shadow(0 0 20px rgba(251,191,36,0.5))' : 'none',
        }}
      >
        {isNewRecord ? 'New Record!' : 'Game Over'}
      </h2>
      <p className="text-slate-400 text-sm mb-6">
        {isNewRecord ? '🎉 You beat the high score!' : 'Better luck next time!'}
      </p>

      {/* Score display */}
      <div
        className="rounded-2xl px-6 py-5 mb-6"
        style={{
          background: 'rgba(255,255,255,0.05)',
          border: '1px solid rgba(255,255,255,0.1)',
        }}
      >
        <div className="text-6xl font-black text-white mb-1">
          <AnimatedNumber value={score} />
        </div>
        <div className="text-slate-400 text-sm">Final Score</div>

        <div className="flex gap-4 justify-center mt-4 pt-4" style={{ borderTop: '1px solid rgba(255,255,255,0.08)' }}>
          <div>
            <div className="text-yellow-400 font-bold text-xl">{highScore}</div>
            <div className="text-slate-500 text-xs">Best</div>
          </div>
          <div style={{ width: 1, background: 'rgba(255,255,255,0.1)' }} />
          <div>
            <div className="text-purple-400 font-bold text-xl">{level}</div>
            <div className="text-slate-500 text-xs">Level</div>
          </div>
        </div>
      </div>

      {/* Performance rating */}
      <div className="mb-6">
        {score === 0 && <RatingBar label="Keep Trying!" stars={1} color="#94a3b8" />}
        {score > 0 && score < 50 && <RatingBar label="Beginner" stars={2} color="#22c55e" />}
        {score >= 50 && score < 150 && <RatingBar label="Getting Better!" stars={3} color="#3b82f6" />}
        {score >= 150 && score < 300 && <RatingBar label="Impressive!" stars={4} color="#a78bfa" />}
        {score >= 300 && <RatingBar label="Snake Master!" stars={5} color="#f59e0b" />}
      </div>

      <button
        onClick={onRestart}
        className="w-full py-4 rounded-2xl font-black text-xl text-white transition-all duration-200 active:scale-95 hover:scale-105"
        style={{
          background: 'linear-gradient(135deg, #22c55e, #16a34a)',
          boxShadow: '0 0 30px rgba(34,197,94,0.5), 0 4px 15px rgba(0,0,0,0.3)',
        }}
      >
        🔄 Play Again
      </button>
      <p className="text-slate-500 text-xs mt-3">Press <kbd className="text-slate-300">Space</kbd> or <kbd className="text-slate-300">Enter</kbd> to restart</p>
    </div>
  );
}

function StatCard({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div
      className="rounded-xl p-3"
      style={{ background: `${color}15`, border: `1px solid ${color}30` }}
    >
      <div className="text-2xl font-black" style={{ color }}>{value}</div>
      <div className="text-slate-400 text-xs">{label}</div>
    </div>
  );
}

function RatingBar({ label, stars }: { label: string; stars: number; color: string }) {
  return (
    <div className="flex items-center justify-between px-3 py-2 rounded-xl" style={{ background: 'rgba(255,255,255,0.04)' }}>
      <span className="text-slate-300 text-sm font-semibold">{label}</span>
      <div className="flex gap-1">
        {Array.from({ length: 5 }).map((_, i) => (
          <span key={i} className="text-lg transition-all" style={{ filter: i < stars ? 'none' : 'grayscale(1) opacity(0.3)' }}>
            ⭐
          </span>
        ))}
      </div>
    </div>
  );
}
