import { useEffect, useRef, useState } from 'react';

interface GameHUDProps {
  score: number;
  highScore: number;
  level: number;
  combo: number;
  snakeLength: number;
}

function ScoreDisplay({ label, value, color, icon }: { label: string; value: number; color: string; icon: string }) {
  const prevRef = useRef(value);
  const [flash, setFlash] = useState(false);

  useEffect(() => {
    if (value !== prevRef.current) {
      prevRef.current = value;
      setFlash(true);
      const t = setTimeout(() => setFlash(false), 400);
      return () => clearTimeout(t);
    }
  }, [value]);

  return (
    <div
      className="flex-1 text-center rounded-2xl py-2 px-3 transition-all duration-200"
      style={{
        background: flash ? `${color}20` : 'rgba(255,255,255,0.05)',
        border: `1px solid ${flash ? color + '50' : 'rgba(255,255,255,0.08)'}`,
        transform: flash ? 'scale(1.05)' : 'scale(1)',
      }}
    >
      <div className="text-lg font-black" style={{ color }}>{value.toLocaleString()}</div>
      <div className="text-xs text-slate-500 flex items-center justify-center gap-1">
        <span>{icon}</span>
        <span>{label}</span>
      </div>
    </div>
  );
}

function LevelBar({ level }: { level: number }) {
  return (
    <div className="flex items-center gap-2">
      <div
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl"
        style={{
          background: 'linear-gradient(135deg, rgba(139,92,246,0.2), rgba(99,102,241,0.2))',
          border: '1px solid rgba(139,92,246,0.3)',
        }}
      >
        <span className="text-xs font-black text-purple-400">LVL</span>
        <span className="text-sm font-black text-purple-300">{level}</span>
      </div>
    </div>
  );
}

export default function GameHUD({ score, highScore, level, combo, snakeLength }: GameHUDProps) {
  const [comboVisible, setComboVisible] = useState(false);
  const comboTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const prevComboRef = useRef(combo);

  useEffect(() => {
    if (combo > 1 && combo !== prevComboRef.current) {
      setComboVisible(true);
      if (comboTimerRef.current) clearTimeout(comboTimerRef.current);
      comboTimerRef.current = setTimeout(() => setComboVisible(false), 1500);
    }
    prevComboRef.current = combo;
  }, [combo]);

  return (
    <div className="w-full">
      {/* Main stats row */}
      <div className="flex gap-2 mb-2">
        <ScoreDisplay label="Score" value={score} color="#4ade80" icon="🎯" />
        <ScoreDisplay label="Best" value={highScore} color="#fbbf24" icon="🏆" />
        <ScoreDisplay label="Length" value={snakeLength} color="#60a5fa" icon="🐍" />
      </div>

      {/* Level + Combo row */}
      <div className="flex items-center justify-between">
        <LevelBar level={level} />

        {/* Combo indicator */}
        <div
          className="transition-all duration-300 overflow-hidden"
          style={{
            maxHeight: comboVisible ? 40 : 0,
            opacity: comboVisible ? 1 : 0,
            transform: comboVisible ? 'translateY(0) scale(1)' : 'translateY(-8px) scale(0.9)',
          }}
        >
          <div
            className="px-3 py-1.5 rounded-xl flex items-center gap-1.5"
            style={{
              background: 'linear-gradient(135deg, rgba(245,158,11,0.25), rgba(251,191,36,0.15))',
              border: '1px solid rgba(245,158,11,0.4)',
            }}
          >
            <span className="text-sm">🔥</span>
            <span className="text-xs font-black text-yellow-400">x{combo} COMBO!</span>
          </div>
        </div>

        {/* Speed indicator */}
        <div
          className="flex items-center gap-1 px-3 py-1.5 rounded-xl"
          style={{
            background: 'rgba(255,255,255,0.04)',
            border: '1px solid rgba(255,255,255,0.08)',
          }}
        >
          <span className="text-xs">⚡</span>
          <div className="flex gap-0.5">
            {Array.from({ length: 5 }).map((_, i) => (
              <div
                key={i}
                className="rounded-full transition-all duration-300"
                style={{
                  width: 4,
                  height: 12,
                  background: i < Math.min(level, 5)
                    ? level <= 2 ? '#22c55e'
                      : level <= 4 ? '#f59e0b'
                        : '#ef4444'
                    : 'rgba(255,255,255,0.1)',
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
