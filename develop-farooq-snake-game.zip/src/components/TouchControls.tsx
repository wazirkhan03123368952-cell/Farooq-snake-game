import { useCallback, useRef } from 'react';
import type { Direction } from '../hooks/useSnakeGame';

interface TouchControlsProps {
  onDirection: (dir: Direction) => void;
  onPause: () => void;
  isPlaying: boolean;
}

interface DPadButtonProps {
  direction: Direction;
  onClick: () => void;
  label: string;
  icon: string;
}

function DPadButton({ onClick, label, icon }: DPadButtonProps) {
  const pressedRef = useRef(false);

  const handleStart = useCallback((e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault();
    if (!pressedRef.current) {
      pressedRef.current = true;
      onClick();
    }
  }, [onClick]);

  const handleEnd = useCallback(() => {
    pressedRef.current = false;
  }, []);

  return (
    <button
      aria-label={label}
      onTouchStart={handleStart}
      onMouseDown={handleStart}
      onTouchEnd={handleEnd}
      onMouseUp={handleEnd}
      className="flex items-center justify-center rounded-2xl font-bold text-2xl select-none transition-all duration-75 active:scale-90"
      style={{
        width: 56,
        height: 56,
        background: 'rgba(255,255,255,0.08)',
        border: '1.5px solid rgba(255,255,255,0.15)',
        color: '#94a3b8',
        WebkitTapHighlightColor: 'transparent',
        touchAction: 'none',
        userSelect: 'none',
      }}
    >
      {icon}
    </button>
  );
}

export default function TouchControls({ onDirection, onPause, isPlaying }: TouchControlsProps) {
  // Swipe detection
  const touchStartRef = useRef<{ x: number; y: number } | null>(null);

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    const t = e.touches[0];
    touchStartRef.current = { x: t.clientX, y: t.clientY };
  }, []);

  const handleTouchEnd = useCallback((e: React.TouchEvent) => {
    if (!touchStartRef.current) return;
    const t = e.changedTouches[0];
    const dx = t.clientX - touchStartRef.current.x;
    const dy = t.clientY - touchStartRef.current.y;
    const absDx = Math.abs(dx);
    const absDy = Math.abs(dy);

    if (Math.max(absDx, absDy) < 20) return; // Too small

    if (absDx > absDy) {
      onDirection(dx > 0 ? 'RIGHT' : 'LEFT');
    } else {
      onDirection(dy > 0 ? 'DOWN' : 'UP');
    }
    touchStartRef.current = null;
  }, [onDirection]);

  return (
    <div className="flex flex-col items-center gap-3 mt-4">
      {/* D-Pad */}
      <div
        className="grid gap-2"
        style={{ gridTemplateColumns: 'repeat(3, 56px)', gridTemplateRows: 'repeat(3, 56px)' }}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        {/* Row 1: empty, up, empty */}
        <div />
        <DPadButton direction="UP" onClick={() => onDirection('UP')} label="Up" icon="▲" />
        <div />

        {/* Row 2: left, center, right */}
        <DPadButton direction="LEFT" onClick={() => onDirection('LEFT')} label="Left" icon="◀" />
        <div
          className="rounded-2xl flex items-center justify-center"
          style={{
            background: 'rgba(255,255,255,0.04)',
            border: '1px solid rgba(255,255,255,0.08)',
          }}
        >
          <span className="text-slate-600 text-xl">●</span>
        </div>
        <DPadButton direction="RIGHT" onClick={() => onDirection('RIGHT')} label="Right" icon="▶" />

        {/* Row 3: empty, down, empty */}
        <div />
        <DPadButton direction="DOWN" onClick={() => onDirection('DOWN')} label="Down" icon="▼" />
        <div />
      </div>

      {/* Pause button */}
      <button
        onClick={onPause}
        className="mt-1 px-6 py-2 rounded-xl text-sm font-bold transition-all duration-150 active:scale-95"
        style={{
          background: 'rgba(255,255,255,0.07)',
          border: '1px solid rgba(255,255,255,0.12)',
          color: '#64748b',
          WebkitTapHighlightColor: 'transparent',
        }}
      >
        {isPlaying ? '⏸ Pause' : '▶ Resume'}
      </button>
    </div>
  );
}
