import { useRef, useEffect } from 'react';
import type { Point, Food, Particle } from '../hooks/useSnakeGame';

interface GameCanvasProps {
  snake: Point[];
  food: Food;
  particles: Particle[];
  gridSize: number;
  cellSize: number;
  canvasSize: number;
  isPulsing: boolean;
}

function getSnakeColor(index: number, length: number): string {
  if (index === 0) return '#4ade80'; // head - bright green
  const t = index / Math.max(length - 1, 1);
  // Gradient from bright green to deep teal
  const r = Math.round(34 + t * (6 - 34));
  const g = Math.round(197 + t * (148 - 197));
  const b = Math.round(94 + t * (160 - 94));
  return `rgb(${r},${g},${b})`;
}

export default function GameCanvas({
  snake,
  food,
  particles,
  gridSize,
  cellSize,
  canvasSize,
  isPulsing,
}: GameCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pulseRef = useRef(0);
  const foodBounceRef = useRef(0);
  const eyeBlinkRef = useRef(0);
  const glowRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas resolution for retina
    const dpr = window.devicePixelRatio || 1;
    canvas.width = canvasSize * dpr;
    canvas.height = canvasSize * dpr;
    canvas.style.width = `${canvasSize}px`;
    canvas.style.height = `${canvasSize}px`;
    ctx.scale(dpr, dpr);

    let animId: number;

    function draw(timestamp: number) {
      pulseRef.current = timestamp * 0.004;
      foodBounceRef.current = Math.sin(timestamp * 0.004) * 2;
      eyeBlinkRef.current = timestamp * 0.003;
      glowRef.current = (Math.sin(timestamp * 0.003) + 1) / 2;

      // Clear
      ctx!.clearRect(0, 0, canvasSize, canvasSize);

      // Background grid
      drawGrid(ctx!, canvasSize, cellSize, gridSize);

      // Particles
      drawParticles(ctx!, particles, cellSize);

      // Food
      drawFood(ctx!, food, cellSize, foodBounceRef.current, glowRef.current, timestamp);

      // Snake
      drawSnake(ctx!, snake, cellSize, eyeBlinkRef.current, glowRef.current);

      animId = requestAnimationFrame(draw);
    }

    animId = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(animId);
  }, [snake, food, particles, gridSize, cellSize, canvasSize, isPulsing]);

  return (
    <canvas
      ref={canvasRef}
      className="rounded-2xl"
      style={{ imageRendering: 'pixelated' }}
    />
  );
}

function drawGrid(ctx: CanvasRenderingContext2D, size: number, cell: number, grid: number) {
  // Background
  ctx.fillStyle = '#0f172a';
  ctx.beginPath();
  ctx.roundRect(0, 0, size, size, 16);
  ctx.fill();

  // Subtle grid lines
  ctx.strokeStyle = 'rgba(255,255,255,0.03)';
  ctx.lineWidth = 0.5;
  for (let i = 0; i <= grid; i++) {
    ctx.beginPath();
    ctx.moveTo(i * cell, 0);
    ctx.lineTo(i * cell, size);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(0, i * cell);
    ctx.lineTo(size, i * cell);
    ctx.stroke();
  }

  // Subtle dots at intersections
  ctx.fillStyle = 'rgba(255,255,255,0.04)';
  for (let x = 0; x <= grid; x++) {
    for (let y = 0; y <= grid; y++) {
      ctx.beginPath();
      ctx.arc(x * cell, y * cell, 1, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

function drawSnake(
  ctx: CanvasRenderingContext2D,
  snake: Point[],
  cell: number,
  eyeBlink: number,
  glow: number
) {
  if (snake.length === 0) return;

  const pad = 1.5;
  const radius = cell / 2 - 1;

  // Draw body segments (from tail to head)
  for (let i = snake.length - 1; i >= 0; i--) {
    const seg = snake[i];
    const x = seg.x * cell + pad;
    const y = seg.y * cell + pad;
    const w = cell - pad * 2;
    const h = cell - pad * 2;

    const color = getSnakeColor(i, snake.length);

    // Glow effect for head
    if (i === 0) {
      ctx.shadowColor = '#4ade80';
      ctx.shadowBlur = 12 + glow * 8;
    } else {
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;
    }

    // Draw segment
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, radius);
    ctx.fill();

    // Inner highlight
    const gradient = ctx.createLinearGradient(x, y, x, y + h / 2);
    gradient.addColorStop(0, 'rgba(255,255,255,0.2)');
    gradient.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.roundRect(x + 1, y + 1, w - 2, h / 2, radius - 1);
    ctx.fill();

    // Scale pattern on body
    if (i > 0 && i % 2 === 0) {
      ctx.fillStyle = 'rgba(0,0,0,0.1)';
      ctx.beginPath();
      ctx.arc(x + w / 2, y + h / 2, w * 0.2, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Reset shadow
  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;

  // Draw head details (eyes)
  const head = snake[0];
  const neck = snake[1] || head;
  const hx = head.x * cell;
  const hy = head.y * cell;

  // Determine direction for eye placement
  const dx = head.x - neck.x;
  const dy = head.y - neck.y;

  let eye1: Point, eye2: Point;

  if (dx > 0) { // RIGHT
    eye1 = { x: hx + cell * 0.65, y: hy + cell * 0.3 };
    eye2 = { x: hx + cell * 0.65, y: hy + cell * 0.7 };
  } else if (dx < 0) { // LEFT
    eye1 = { x: hx + cell * 0.35, y: hy + cell * 0.3 };
    eye2 = { x: hx + cell * 0.35, y: hy + cell * 0.7 };
  } else if (dy < 0) { // UP
    eye1 = { x: hx + cell * 0.3, y: hy + cell * 0.35 };
    eye2 = { x: hx + cell * 0.7, y: hy + cell * 0.35 };
  } else { // DOWN
    eye1 = { x: hx + cell * 0.3, y: hy + cell * 0.65 };
    eye2 = { x: hx + cell * 0.7, y: hy + cell * 0.65 };
  }

  const eyeRadius = cell * 0.12;
  const isBlinking = Math.sin(eyeBlink) > 0.97;

  // Eyes
  [eye1, eye2].forEach(eye => {
    // White
    ctx.fillStyle = 'white';
    ctx.beginPath();
    ctx.arc(eye.x, eye.y, eyeRadius, 0, Math.PI * 2);
    ctx.fill();

    if (isBlinking) {
      // Blink
      ctx.strokeStyle = '#1e293b';
      ctx.lineWidth = eyeRadius * 1.2;
      ctx.beginPath();
      ctx.moveTo(eye.x - eyeRadius, eye.y);
      ctx.lineTo(eye.x + eyeRadius, eye.y);
      ctx.stroke();
    } else {
      // Pupil
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.arc(eye.x + eyeRadius * 0.2, eye.y + eyeRadius * 0.2, eyeRadius * 0.55, 0, Math.PI * 2);
      ctx.fill();

      // Eye shine
      ctx.fillStyle = 'white';
      ctx.beginPath();
      ctx.arc(eye.x + eyeRadius * 0.1, eye.y, eyeRadius * 0.2, 0, Math.PI * 2);
      ctx.fill();
    }
  });

  // Tongue
  if (!isBlinking && Math.sin(eyeBlink * 1.5) > 0.5) {
    ctx.strokeStyle = '#f43f5e';
    ctx.lineWidth = 1.5;
    ctx.lineCap = 'round';

    let tx = head.x * cell + cell / 2;
    let ty = head.y * cell + cell / 2;
    let tEndX = tx, tEndY = ty;
    const tLen = cell * 0.5;

    if (dx > 0) { tEndX = tx + tLen; tEndY = ty; }
    else if (dx < 0) { tEndX = tx - tLen; tEndY = ty; }
    else if (dy < 0) { tEndX = tx; tEndY = ty - tLen; }
    else { tEndX = tx; tEndY = ty + tLen; }

    ctx.beginPath();
    ctx.moveTo(tx, ty);
    ctx.lineTo(tEndX, tEndY);
    ctx.stroke();

    // Fork
    const forkLen = cell * 0.15;
    ctx.beginPath();
    ctx.moveTo(tEndX, tEndY);
    if (dx !== 0) {
      ctx.lineTo(tEndX + (dx > 0 ? forkLen * 0.5 : -forkLen * 0.5), tEndY - forkLen);
      ctx.moveTo(tEndX, tEndY);
      ctx.lineTo(tEndX + (dx > 0 ? forkLen * 0.5 : -forkLen * 0.5), tEndY + forkLen);
    } else {
      ctx.lineTo(tEndX - forkLen, tEndY + (dy < 0 ? -forkLen * 0.5 : forkLen * 0.5));
      ctx.moveTo(tEndX, tEndY);
      ctx.lineTo(tEndX + forkLen, tEndY + (dy < 0 ? -forkLen * 0.5 : forkLen * 0.5));
    }
    ctx.stroke();
  }
}

function drawFood(
  ctx: CanvasRenderingContext2D,
  food: Food,
  cell: number,
  bounce: number,
  glow: number,
  timestamp: number
) {
  const x = food.position.x * cell + cell / 2;
  const y = food.position.y * cell + cell / 2 + bounce;
  const radius = cell * 0.38;
  const glowColor = food.color;

  // Glow
  ctx.shadowColor = glowColor;
  ctx.shadowBlur = 15 + glow * 15;

  // Background circle
  ctx.fillStyle = glowColor + '33';
  ctx.beginPath();
  ctx.arc(x, y, radius * 1.4, 0, Math.PI * 2);
  ctx.fill();

  // Pulsing ring
  const ringScale = 1 + Math.sin(timestamp * 0.005) * 0.15;
  ctx.strokeStyle = glowColor + '66';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(x, y, radius * 1.6 * ringScale, 0, Math.PI * 2);
  ctx.stroke();

  // Emoji
  ctx.shadowBlur = 0;
  ctx.font = `${Math.round(cell * 0.65)}px serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(food.emoji, x, y + 1);
}

function drawParticles(ctx: CanvasRenderingContext2D, particles: Particle[], cell: number) {
  particles.forEach(p => {
    const alpha = p.life / p.maxLife;
    const x = p.x * cell + cell / 2;
    const y = p.y * cell + cell / 2;

    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.fillStyle = p.color;
    ctx.shadowColor = p.color;
    ctx.shadowBlur = 6;
    ctx.beginPath();
    ctx.arc(x + p.vx * (1 - alpha) * cell * 3, y + p.vy * (1 - alpha) * cell * 3, p.size * alpha, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  });
}
