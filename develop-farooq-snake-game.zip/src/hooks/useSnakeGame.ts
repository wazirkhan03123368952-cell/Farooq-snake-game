import { useState, useEffect, useCallback, useRef } from 'react';

export type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';
export type GameStatus = 'IDLE' | 'PLAYING' | 'PAUSED' | 'GAME_OVER';
export type FoodType = 'NORMAL' | 'BONUS' | 'SPEED' | 'SHRINK';

export interface Point {
  x: number;
  y: number;
}

export interface Food {
  position: Point;
  type: FoodType;
  value: number;
  emoji: string;
  color: string;
}

export interface Particle {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  life: number;
  maxLife: number;
  size: number;
}

interface GameState {
  snake: Point[];
  food: Food;
  direction: Direction;
  status: GameStatus;
  score: number;
  highScore: number;
  level: number;
  lives: number;
  particles: Particle[];
  combo: number;
  totalFoodEaten: number;
}

const GRID_SIZE = 20;

const FOOD_TYPES: { type: FoodType; weight: number; value: number; emoji: string; color: string }[] = [
  { type: 'NORMAL',  weight: 60, value: 10,  emoji: '🍎', color: '#ef4444' },
  { type: 'BONUS',   weight: 20, value: 30,  emoji: '⭐', color: '#f59e0b' },
  { type: 'SPEED',   weight: 10, value: 20,  emoji: '⚡', color: '#8b5cf6' },
  { type: 'SHRINK',  weight: 10, value: 50,  emoji: '💎', color: '#06b6d4' },
];

function getRandomFoodType(): { type: FoodType; value: number; emoji: string; color: string } {
  const rand = Math.random() * 100;
  let cumulative = 0;
  for (const ft of FOOD_TYPES) {
    cumulative += ft.weight;
    if (rand < cumulative) return ft;
  }
  return FOOD_TYPES[0];
}

function getRandomFood(snake: Point[]): Food {
  let position: Point;
  do {
    position = {
      x: Math.floor(Math.random() * GRID_SIZE),
      y: Math.floor(Math.random() * GRID_SIZE),
    };
  } while (snake.some(s => s.x === position.x && s.y === position.y));

  const ft = getRandomFoodType();
  return { position, ...ft };
}

function getInitialSnake(): Point[] {
  const mid = Math.floor(GRID_SIZE / 2);
  return [
    { x: mid, y: mid },
    { x: mid - 1, y: mid },
    { x: mid - 2, y: mid },
  ];
}

const BASE_SPEED = 150;
const MIN_SPEED = 60;

function getSpeed(level: number): number {
  return Math.max(MIN_SPEED, BASE_SPEED - (level - 1) * 12);
}

export function useSnakeGame() {
  const initialSnake = getInitialSnake();
  const initialFood = getRandomFood(initialSnake);

  const [state, setState] = useState<GameState>({
    snake: initialSnake,
    food: initialFood,
    direction: 'RIGHT',
    status: 'IDLE',
    score: 0,
    highScore: parseInt(localStorage.getItem('farooq-snake-highscore') || '0'),
    level: 1,
    lives: 3,
    particles: [],
    combo: 0,
    totalFoodEaten: 0,
  });

  const directionRef = useRef<Direction>('RIGHT');
  const pendingDirectionRef = useRef<Direction | null>(null);
  const stateRef = useRef(state);
  const particleIdRef = useRef(0);

  stateRef.current = state;

  // Save high score
  useEffect(() => {
    if (state.score > state.highScore) {
      localStorage.setItem('farooq-snake-highscore', String(state.score));
      setState(prev => ({ ...prev, highScore: state.score }));
    }
  }, [state.score]);



  const moveSnake = useCallback(() => {
    setState(prev => {
      if (prev.status !== 'PLAYING') return prev;

      // Apply pending direction
      if (pendingDirectionRef.current) {
        directionRef.current = pendingDirectionRef.current;
        pendingDirectionRef.current = null;
      }

      const dir = directionRef.current;
      const head = prev.snake[0];
      let newHead: Point;

      switch (dir) {
        case 'UP':    newHead = { x: head.x, y: head.y - 1 }; break;
        case 'DOWN':  newHead = { x: head.x, y: head.y + 1 }; break;
        case 'LEFT':  newHead = { x: head.x - 1, y: head.y }; break;
        case 'RIGHT': newHead = { x: head.x + 1, y: head.y }; break;
      }

      // Wall collision
      if (
        newHead.x < 0 || newHead.x >= GRID_SIZE ||
        newHead.y < 0 || newHead.y >= GRID_SIZE
      ) {
        return { ...prev, status: 'GAME_OVER' };
      }

      // Self collision (ignore last segment which will be removed)
      if (prev.snake.slice(0, -1).some(s => s.x === newHead.x && s.y === newHead.y)) {
        return { ...prev, status: 'GAME_OVER' };
      }

      const ateFood =
        newHead.x === prev.food.position.x &&
        newHead.y === prev.food.position.y;

      let newSnake: Point[];
      let newFood = prev.food;
      let newScore = prev.score;
      let newLevel = prev.level;
      let newParticles = prev.particles
        .map(p => ({ ...p, x: p.x + p.vx, y: p.y + p.vy, life: p.life - 0.05 }))
        .filter(p => p.life > 0);
      let newCombo = prev.combo;
      let newTotalFoodEaten = prev.totalFoodEaten;

      if (ateFood) {
        newCombo = prev.combo + 1;
        newTotalFoodEaten = prev.totalFoodEaten + 1;
        const comboBonus = Math.floor(newCombo / 3) * 5;
        const points = prev.food.value + comboBonus;
        newScore = prev.score + points;

        // Spawn particles at food position (grid coords)
        const foodParticles = [];
        const count = prev.food.type === 'BONUS' ? 16 : prev.food.type === 'SHRINK' ? 12 : 8;
        for (let i = 0; i < count; i++) {
          const angle = (i / count) * Math.PI * 2;
          const speed = 1.5 + Math.random() * 2;
          foodParticles.push({
            id: particleIdRef.current++,
            x: prev.food.position.x,
            y: prev.food.position.y,
            vx: Math.cos(angle) * speed * 0.15,
            vy: Math.sin(angle) * speed * 0.15,
            color: prev.food.color,
            life: 1,
            maxLife: 1,
            size: 4 + Math.random() * 6,
          });
        }
        newParticles = [...newParticles, ...foodParticles];

        // Handle food type effects
        if (prev.food.type === 'SHRINK' && prev.snake.length > 3) {
          // Shrink snake by 2
          newSnake = [newHead, ...prev.snake.slice(0, Math.max(3, prev.snake.length - 2))];
        } else {
          newSnake = [newHead, ...prev.snake]; // grow
        }

        newFood = getRandomFood(newSnake);
        newLevel = Math.floor(newTotalFoodEaten / 5) + 1;
      } else {
        newSnake = [newHead, ...prev.snake.slice(0, -1)];
        newCombo = 0;
      }

      return {
        ...prev,
        snake: newSnake,
        food: newFood,
        direction: directionRef.current,
        score: newScore,
        level: newLevel,
        particles: newParticles,
        combo: newCombo,
        totalFoodEaten: newTotalFoodEaten,
      };
    });
  }, []);

  // Game loop
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (state.status === 'PLAYING') {
      const speed = getSpeed(state.level);
      if (intervalRef.current) clearInterval(intervalRef.current);
      intervalRef.current = setInterval(moveSnake, speed);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [state.status, state.level, moveSnake]);

  // Check for game over and save high score
  useEffect(() => {
    if (state.status === 'GAME_OVER') {
      const hs = parseInt(localStorage.getItem('farooq-snake-highscore') || '0');
      if (state.score > hs) {
        localStorage.setItem('farooq-snake-highscore', String(state.score));
        setState(prev => ({ ...prev, highScore: state.score }));
      }
    }
  }, [state.status]);

  // Keyboard controls
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    const { status } = stateRef.current;

    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      if (status === 'IDLE' || status === 'GAME_OVER') {
        startGame();
      } else if (status === 'PLAYING') {
        pauseGame();
      } else if (status === 'PAUSED') {
        resumeGame();
      }
      return;
    }

    if (e.key === 'Escape') {
      e.preventDefault();
      if (status === 'PLAYING') pauseGame();
      else if (status === 'PAUSED') resumeGame();
      return;
    }

    if (status !== 'PLAYING') return;

    const currentDir = directionRef.current;
    const dirMap: Record<string, Direction> = {
      ArrowUp: 'UP', w: 'UP', W: 'UP',
      ArrowDown: 'DOWN', s: 'DOWN', S: 'DOWN',
      ArrowLeft: 'LEFT', a: 'LEFT', A: 'LEFT',
      ArrowRight: 'RIGHT', d: 'RIGHT', D: 'RIGHT',
    };

    const newDir = dirMap[e.key];
    if (!newDir) return;
    e.preventDefault();

    const opposites: Record<Direction, Direction> = {
      UP: 'DOWN', DOWN: 'UP', LEFT: 'RIGHT', RIGHT: 'LEFT',
    };
    if (newDir !== opposites[currentDir]) {
      pendingDirectionRef.current = newDir;
    }
  }, []);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  const startGame = useCallback(() => {
    const snake = getInitialSnake();
    const food = getRandomFood(snake);
    directionRef.current = 'RIGHT';
    pendingDirectionRef.current = null;
    const hs = parseInt(localStorage.getItem('farooq-snake-highscore') || '0');
    setState(prev => ({
      snake,
      food,
      direction: 'RIGHT',
      status: 'PLAYING',
      score: 0,
      highScore: Math.max(prev.highScore, hs),
      level: 1,
      lives: 3,
      particles: [],
      combo: 0,
      totalFoodEaten: 0,
    }));
  }, []);

  const pauseGame = useCallback(() => {
    setState(prev => prev.status === 'PLAYING' ? { ...prev, status: 'PAUSED' } : prev);
  }, []);

  const resumeGame = useCallback(() => {
    setState(prev => prev.status === 'PAUSED' ? { ...prev, status: 'PLAYING' } : prev);
  }, []);

  const changeDirection = useCallback((dir: Direction) => {
    const opposites: Record<Direction, Direction> = {
      UP: 'DOWN', DOWN: 'UP', LEFT: 'RIGHT', RIGHT: 'LEFT',
    };
    if (dir !== opposites[directionRef.current]) {
      pendingDirectionRef.current = dir;
    }
  }, []);

  return {
    state,
    startGame,
    pauseGame,
    resumeGame,
    changeDirection,
    gridSize: GRID_SIZE,
    getSpeed,
  };
}
